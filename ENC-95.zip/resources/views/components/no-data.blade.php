<tr>

    <td colspan="{{ $colspan }}" class="text-center">
        <div class="d-flex flex-column align-items-center">
           
        <img src="{{ asset('assets/images/no-data.svg') }}" alt="No Data" class="img-fluid">
       <h5>{{$text}}</h5>
        </div>
    </td>
</tr>