const sock = [];
const qrcode = [];
const pairingCode = [];
const intervalStore = [];

module.exports = { sock, qrcode, pairingCode, intervalStore };
