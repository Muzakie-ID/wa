 <header class="top-header">
     <nav class="navbar navbar-expand gap-3 align-items-center">
         <div class="mobile-toggle-icon fs-3">
             <i class="bi bi-list"></i>
         </div>
         <form class="searchbar">
             <div class="position-absolute top-50 translate-middle-y search-icon ms-3"><i class="bi bi-search"></i></div>
             <input class="form-control" type="text" placeholder="<?php echo e(__('Type here to search')); ?>">
             <div class="position-absolute top-50 translate-middle-y search-close-icon"><i class="bi bi-x-lg"></i></div>
         </form>
         <div class="top-navbar-right ms-auto">
             <ul class="navbar-nav align-items-center">
                 <li class="nav-item search-toggle-icon">
                     <a class="nav-link" href="#">
                         <div class="">
                             <i class="bi bi-search"></i>
                         </div>
                     </a>
                 </li>
                 <li class="nav-item dropdown">
                     <a class="nav-link dropdown-toggle" href="#" id="languageDropdown" role="button"
                         data-bs-toggle="dropdown" aria-expanded="false" style="font-size: 15px;">
                         <i class="bi bi-globe"></i>
                         <?php echo e(__('Language')); ?>

                     </a>
                     <ul class="dropdown-menu" aria-labelledby="languageDropdown">
                         <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <li>
                                 <a class="dropdown-item" rel="alternate" hreflang="<?php echo e($localeCode); ?>"
                                     href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>">
                                     <span class="flag-icon flag-icon-<?php echo e(strtolower($localeCode)); ?>"></span>
                                     <?php echo e($properties['native']); ?>

                                 </a>
                             </li>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </ul>
                 </li>
                 <li class="nav-item dropdown dropdown-user-setting">
                     <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" href="#"
                         data-bs-toggle="dropdown">
                         <div class="user-setting d-flex align-items-center">
                             <img src="<?php echo e(asset('assets/images/avatars/avatar-1.png')); ?>" class="user-img"
                                 alt="">
                         </div>
                     </a>
                     <ul class="dropdown-menu dropdown-menu-end">
                         <li>
                             <a class="dropdown-item" href="#">
                                 <div class="d-flex align-items-center">
                                     <img src="<?php echo e(asset('assets/images/avatars/avatar-1.png')); ?>" alt=""
                                         class="rounded-circle" width="54" height="54">
                                     <div class="ms-3">
                                         <h6 class="mb-0 dropdown-user-name"><?php echo e(Auth::user()->username); ?></h6>
                                         <small
                                             class="mb-0 dropdown-user-designation text-secondary"><?php echo e(__(Auth::user()->level)); ?></small>
                                     </div>
                                 </div>
                             </a>
                         </li>
                         <li>
                             <hr class="dropdown-divider">
                         </li>

                         <li>
                             <a class="dropdown-item" href="<?php echo e(route('user.settings')); ?>">
                                 <div class="d-flex align-items-center">
                                     <div class=""><i class="bi bi-gear-fill"></i></div>
                                     <div class="ms-3"><span><?php echo e(__('Setting')); ?></span></div>
                                 </div>
                             </a>
                         </li>

                         <li>
                             <hr class="dropdown-divider">
                         </li>
                         <li>
                             <form action="<?php echo e(route('logout')); ?>" method="post">
                                 <?php echo csrf_field(); ?>
                                 <button class="dropdown-item" type="submit">
                                     <div class="d-flex align-items-center">
                                         <div class=""><i class="bi bi-lock-fill"></i></div>
                                         <div class="ms-3"><span><?php echo e(__('Logout')); ?></span></div>
                                     </div>
                                 </button>
                             </form>
                         </li>
                     </ul>
                 </li>
             </ul>
         </div>
     </nav>
 </header>
<?php /**PATH /Users/ilmans/Documents/Projects/Laravel/whatsapp-gateway/resources/views/components/header.blade.php ENDPATH**/ ?>